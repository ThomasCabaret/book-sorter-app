EXAMPLE only: initial books, NO user vote events.
